var PORT_NO = ???;
var http = require('http');

function start(router) {
    var server = http.createServer(
        function(request, response) {
            router.route(request, response);
        }
    );
    server.listen(PORT_NO);
}

exports.start = start;
